var namespaces_dup =
[
    [ "Project", "namespace_project.html", "namespace_project" ]
];