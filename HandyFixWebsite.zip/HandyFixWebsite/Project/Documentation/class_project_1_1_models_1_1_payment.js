var class_project_1_1_models_1_1_payment =
[
    [ "BillingAddress", "class_project_1_1_models_1_1_payment.html#a34736d8455fd738289a9d968a9bc5d0d", null ],
    [ "CardNumber", "class_project_1_1_models_1_1_payment.html#a885b53d82bf859a3986e1744caf92a49", null ],
    [ "CVV", "class_project_1_1_models_1_1_payment.html#a96be50a71e6196df791406851b2cde5a", null ],
    [ "ExpiryDate", "class_project_1_1_models_1_1_payment.html#aaf135ec6a9ee2e110377b4997fb989fc", null ],
    [ "NameOnCard", "class_project_1_1_models_1_1_payment.html#ac399050072ba7e58a5c74d17528f8975", null ],
    [ "PaymentId", "class_project_1_1_models_1_1_payment.html#a8240b20c2a69dfcfeb1a2ea1d4e640ba", null ],
    [ "PostalCode", "class_project_1_1_models_1_1_payment.html#a2a0d3ddd942af94542fc631280fcace3", null ],
    [ "UserId", "class_project_1_1_models_1_1_payment.html#a33ba0ad295b14c01ccc262ff7deebcd1", null ]
];