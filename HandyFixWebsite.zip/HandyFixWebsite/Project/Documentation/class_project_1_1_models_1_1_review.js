var class_project_1_1_models_1_1_review =
[
    [ "AddUser", "class_project_1_1_models_1_1_review.html#a4fde98cb2ff16642452f095983b33a43", null ],
    [ "Date", "class_project_1_1_models_1_1_review.html#a7682233b96d78f15d00bd233a099f00d", null ],
    [ "Rating", "class_project_1_1_models_1_1_review.html#a5afae913dbc6276a373326efd8aeb16e", null ],
    [ "ReviewId", "class_project_1_1_models_1_1_review.html#a8e5c39f7526a98b0671265c41ca439cc", null ],
    [ "ReviewText", "class_project_1_1_models_1_1_review.html#a106da9b597c599438bfc110f8c80b604", null ],
    [ "ServiceId", "class_project_1_1_models_1_1_review.html#ac3898bdf7858b2c23bd1f856277bf7bc", null ],
    [ "UserId", "class_project_1_1_models_1_1_review.html#a5d7b71c43eb14fbb9257771c88004e67", null ],
    [ "UserName", "class_project_1_1_models_1_1_review.html#a18c26eff470ac16002c402a121581fde", null ]
];