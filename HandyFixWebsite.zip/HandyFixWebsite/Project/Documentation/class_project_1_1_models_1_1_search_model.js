var class_project_1_1_models_1_1_search_model =
[
    [ "Filter", "class_project_1_1_models_1_1_search_model.html#ad678ee8210a37d1bed3d8ec33c10fdc7", null ],
    [ "SearchName", "class_project_1_1_models_1_1_search_model.html#a336284af740c370044d5cc5cb48798a3", null ],
    [ "Services", "class_project_1_1_models_1_1_search_model.html#aa6c0b773226c78bcdc442630f43d871a", null ]
];