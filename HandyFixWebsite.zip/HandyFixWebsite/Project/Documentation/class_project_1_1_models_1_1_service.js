var class_project_1_1_models_1_1_service =
[
    [ "Service", "class_project_1_1_models_1_1_service.html#a3367021a8d12e21f8f7f5f5b24ac2050", null ],
    [ "Service", "class_project_1_1_models_1_1_service.html#a144c2dd1f20b58d3256f3956c8af002f", null ],
    [ "Service", "class_project_1_1_models_1_1_service.html#adf661e084431eb3fceada60813c6ed32", null ],
    [ "AddOneReview", "class_project_1_1_models_1_1_service.html#ad3d4e8beb32440237395d5a39dc40237", null ],
    [ "AddReviews", "class_project_1_1_models_1_1_service.html#a39ebc67e5f02baaefe74fc87b67094e2", null ],
    [ "Description", "class_project_1_1_models_1_1_service.html#ae97ff4d88e31662ec42625fc04e51d50", null ],
    [ "PricePerHour", "class_project_1_1_models_1_1_service.html#a1b1ad58650b1b0cf2b954bd991418cf6", null ],
    [ "Reviews", "class_project_1_1_models_1_1_service.html#a81d35f947031fdf5f31e0e0fcea14d3c", null ],
    [ "ServiceId", "class_project_1_1_models_1_1_service.html#ad49242d999b41872f00a604b2222e2de", null ],
    [ "ServiceName", "class_project_1_1_models_1_1_service.html#a58d35601aaf81dd31dcc57376cbca220", null ],
    [ "ServiceTypeId", "class_project_1_1_models_1_1_service.html#a88692abbdb62779b3767e7caa8be27d1", null ]
];