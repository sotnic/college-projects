var class_project_1_1_models_1_1_general_user =
[
    [ "Apartment", "class_project_1_1_models_1_1_general_user.html#a800bd7f4d8f9a5b893a0693868a7e6d9", null ],
    [ "City", "class_project_1_1_models_1_1_general_user.html#adba65e1886404bcd424e0d5452819bd2", null ],
    [ "Discount", "class_project_1_1_models_1_1_general_user.html#a4fd2737fd4b9c7446487a56a3214f5e0", null ],
    [ "FirstName", "class_project_1_1_models_1_1_general_user.html#a5b81c5cede919c559279cbc0e278cf7a", null ],
    [ "LastName", "class_project_1_1_models_1_1_general_user.html#a0844ac97c63b7c4bba77905cbf054f6d", null ],
    [ "Province", "class_project_1_1_models_1_1_general_user.html#a5ca0528ff8fa5957c3ed5abd3ecbc0ca", null ],
    [ "Street", "class_project_1_1_models_1_1_general_user.html#a7d0174d3d1d71e4391a6edb4fb079fad", null ],
    [ "Telephone", "class_project_1_1_models_1_1_general_user.html#a2054948d579dc0f2c42b1d3c7ffc322e", null ],
    [ "ZIP", "class_project_1_1_models_1_1_general_user.html#a11d0823b4e4a6f0b0a1b9da5834e9400", null ]
];