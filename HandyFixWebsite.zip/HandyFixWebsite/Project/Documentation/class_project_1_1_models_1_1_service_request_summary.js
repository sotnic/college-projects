var class_project_1_1_models_1_1_service_request_summary =
[
    [ "Date", "class_project_1_1_models_1_1_service_request_summary.html#a14f8f50888308e5103bbe197c04e5a33", null ],
    [ "NumberOfHours", "class_project_1_1_models_1_1_service_request_summary.html#a43972c47b533653ab79802d3c8923a40", null ],
    [ "PricePerHour", "class_project_1_1_models_1_1_service_request_summary.html#a1dbc1be82c76217bac79fb5b7eb54039", null ],
    [ "ServiceName", "class_project_1_1_models_1_1_service_request_summary.html#a8b947cee9c0437df2e6f14bd87beb1f6", null ],
    [ "TotalPrice", "class_project_1_1_models_1_1_service_request_summary.html#af21f9118cb8ac9e54adfde415a2e3ad8", null ]
];