var searchData=
[
  ['generaluser',['GeneralUser',['../class_project_1_1_models_1_1_general_user.html',1,'Project::Models']]]
];
