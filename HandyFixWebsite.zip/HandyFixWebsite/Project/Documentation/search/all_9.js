var searchData=
[
  ['nameoncard',['NameOnCard',['../class_project_1_1_models_1_1_payment.html#ac399050072ba7e58a5c74d17528f8975',1,'Project::Models::Payment']]],
  ['numberofhours',['NumberOfHours',['../class_project_1_1_models_1_1_requested_service.html#adf0084eb3ce59ef438811851f4c42b21',1,'Project.Models.RequestedService.NumberOfHours()'],['../class_project_1_1_models_1_1_service_request_summary.html#a43972c47b533653ab79802d3c8923a40',1,'Project.Models.ServiceRequestSummary.NumberOfHours()']]]
];
