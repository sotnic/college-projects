var searchData=
[
  ['requestedservices',['RequestedServices',['../class_project_1_1_models_1_1_service_repository.html#aa06dcdab29a2e97613e8e81a4aa36b41',1,'Project::Models::ServiceRepository']]],
  ['reviews',['Reviews',['../class_project_1_1_models_1_1_service_repository.html#a1b8f01bf27cee62abfc052f65cb8fb3d',1,'Project::Models::ServiceRepository']]]
];
