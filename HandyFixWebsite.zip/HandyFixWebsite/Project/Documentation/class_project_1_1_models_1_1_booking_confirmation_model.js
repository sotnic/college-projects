var class_project_1_1_models_1_1_booking_confirmation_model =
[
    [ "Discount", "class_project_1_1_models_1_1_booking_confirmation_model.html#a6fc89f5ac02c5bec85808cb5ea17bfbc", null ],
    [ "PaymentId", "class_project_1_1_models_1_1_booking_confirmation_model.html#acebd8c1277c6ef3059cb734bbb945456", null ],
    [ "RequestedServiceId", "class_project_1_1_models_1_1_booking_confirmation_model.html#af9fedce77d8be2893020f0338548cd9f", null ],
    [ "ServiceId", "class_project_1_1_models_1_1_booking_confirmation_model.html#ab3e9abb21fd3356b71bc6a078365112e", null ]
];