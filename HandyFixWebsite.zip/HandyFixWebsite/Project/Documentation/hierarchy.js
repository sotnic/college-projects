var hierarchy =
[
    [ "Project.Models.BookingConfirmationModel", "class_project_1_1_models_1_1_booking_confirmation_model.html", null ],
    [ "DbContext", null, [
      [ "Project.Models.ApplicationDbContext", "class_project_1_1_models_1_1_application_db_context.html", null ]
    ] ],
    [ "Project.Models.IdentityDbContext", "class_project_1_1_models_1_1_identity_db_context.html", null ],
    [ "Project.Models.IdentitySeedData", "class_project_1_1_models_1_1_identity_seed_data.html", null ],
    [ "IdentityUser", null, [
      [ "Project.Models.GeneralUser", "class_project_1_1_models_1_1_general_user.html", null ]
    ] ],
    [ "Project.Models.IServiceRepository", "interface_project_1_1_models_1_1_i_service_repository.html", [
      [ "Project.Models.ServiceRepository", "class_project_1_1_models_1_1_service_repository.html", null ]
    ] ],
    [ "Project.Models.LoginModel", "class_project_1_1_models_1_1_login_model.html", null ],
    [ "Project.Models.Payment", "class_project_1_1_models_1_1_payment.html", null ],
    [ "Project.Models.ProfileModel", "class_project_1_1_models_1_1_profile_model.html", null ],
    [ "Project.Models.RegistrationModel", "class_project_1_1_models_1_1_registration_model.html", null ],
    [ "Project.Models.RequestedService", "class_project_1_1_models_1_1_requested_service.html", null ],
    [ "Project.Models.Review", "class_project_1_1_models_1_1_review.html", null ],
    [ "Project.Models.SearchModel", "class_project_1_1_models_1_1_search_model.html", null ],
    [ "Project.Models.Service", "class_project_1_1_models_1_1_service.html", null ],
    [ "Project.Models.ServiceRequestModel", "class_project_1_1_models_1_1_service_request_model.html", null ],
    [ "Project.Models.ServiceRequestSummary", "class_project_1_1_models_1_1_service_request_summary.html", null ],
    [ "Project.Models.ServiceType", "class_project_1_1_models_1_1_service_type.html", null ]
];